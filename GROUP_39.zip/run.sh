cd FRONT_END
export FLASK_APP=app
export FLASK_ENV=development
#TODO: remove this FLASK_ENV as development
flask run -p 5039
cd ..